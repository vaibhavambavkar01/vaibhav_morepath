from importscan.tests.fixtures import call


call()
